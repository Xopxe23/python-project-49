### Hexlet tests and linter status:
[![Actions Status](https://github.com/Xopxe23/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Xopxe23/python-project-49/actions)