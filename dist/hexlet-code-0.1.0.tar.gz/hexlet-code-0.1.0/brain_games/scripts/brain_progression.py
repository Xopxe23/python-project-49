#!/usr/bin/env python3
from brain_games.prog import prog


def main():
    print("Welcome to the Brain Games")
    prog()


if __name__ == "__main__":
    main()
