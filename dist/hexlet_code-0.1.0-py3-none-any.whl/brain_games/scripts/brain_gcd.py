#!/usr/bin/env python3
from brain_games.nod import gcd


def main():
    print("Welcome to the Brain Games")
    gcd()


if __name__ == "__main__":
    main()
