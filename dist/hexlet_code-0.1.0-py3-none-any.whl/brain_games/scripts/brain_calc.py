#!/usr/bin/env python3
from brain_games.calc import calc


def main():
    print("Welcome to the Brain Games")
    calc()


if __name__ == "__main__":
    main()
