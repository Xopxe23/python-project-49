#!/usr/bin/env python3
from brain_games.magic_numbers import magic_numbers


def main():
    print("Welcome to the Brain Games")
    magic_numbers()


if __name__ == "__main__":
    main()
